"""Gives users direct access to the function."""
from truckle.truckle import truckle, greet
